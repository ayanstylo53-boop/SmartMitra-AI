# SmartMitra AI — Android starter

This is a fresh Android WebView wrapper project with a local SmartMitra AI interface and a GitHub Actions workflow template.

## Important
- This project can build an installable **starter APK**.
- The six tool screens are included in the app interface.
- Live Gemini responses are **not connected** yet. The original project README says a secure Node.js backend and Gemini API key must be configured/deployed before AI requests work.
- Do not put a Gemini API key in Android source code or commit it to GitHub.
- This is not a Play Store release build.

## Build on GitHub Actions
1. Put the Android project files at the repository root (the `app` folder, `build.gradle.kts`, `settings.gradle.kts`, and `gradle.properties`).
2. Add the workflow from `github-workflow-template.yml` at `.github/workflows/build-apk.yml`.
3. Push/commit the files.
4. Open the repository's **Actions** tab, open the latest successful run, and download the `SmartMitra-AI-debug-apk` artifact.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on Android.

## App details
- Package: `com.smartmitra.ai`
- Minimum Android: Android 6.0 (API 23)
- Target SDK: 35
