# SmartMitra AI — Android starter project

This repository is arranged at its root for GitHub Actions.

## Build
The GitHub Actions workflow is `.github/workflows/android.yml`. It installs Java 17 and Gradle 8.10.2, then runs `gradle assembleDebug` directly. A Gradle wrapper is not required by this workflow.

On GitHub, upload the CONTENTS of this ZIP to the repository root (not the enclosing ZIP folder). Keep the `.github` folder and its `workflows/android.yml` file.

After committing to `main`, open **Actions**, select **Build SmartMitra AI Debug APK**, open the successful run, and download the `SmartMitra-AI-debug-apk` artifact. The downloaded artifact is a ZIP containing `app-debug.apk`.

## App details
- Application ID: `com.smartmitra.ai`
- Minimum Android: API 23
- Compile/target SDK: 35
- Android Gradle Plugin: 8.7.3
- Gradle: 8.10.2

## Important functionality note
This source contains the SmartMitra AI WebView starter interface and its six tool screens. The HTML itself states that live AI answers are not connected yet and require a deployed secure backend. This ZIP prepares the project for a debug APK build; it does not add a Gemini backend or API key. Never commit a Gemini API key into the Android source or public GitHub repository.
